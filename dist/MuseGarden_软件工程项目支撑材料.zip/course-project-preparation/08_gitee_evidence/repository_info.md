# Gitee 仓库证据

仓库 https://gitee.com/shaaaadowwww/muse-garden 。2026-10-30 本次 `git ls-remote` 返回 HEAD 与 refs/heads/main 均为 d6eb2c968cbdfd7902c1dc4f5ad73dd54e97df6e。本地 HEAD 为 5938363，origin 指向 GitHub；Gitee 上额外有课程清单提交。本次不提交、不推送、不修改 remote。

网页和提交详情截图未采集；ls-remote 只能证明远程引用及哈希，不证明网页内容。
